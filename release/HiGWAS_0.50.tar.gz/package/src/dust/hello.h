#define THREADS_PER_BLOCK 512

void calculate_tau(double *a, double *tau2, double lambda2, double sigma2, int P);
